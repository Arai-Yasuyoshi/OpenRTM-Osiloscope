
public class Dataport {
	int[] datatype;
	String[] dataname;
	
	public void setDatatype(int[] datatype){
		for(int i = 0; i < datatype.length; i++){
			this.datatype[i] = datatype[i];
		}
	}
		
	public void setDataname(String[] dataname){
		for(int i = 0; i < datatype.length; i++){
			this.dataname[i] = dataname[i];
		}
	}
	
	public int[] getDatatype(){
		return this.datatype;
	}
	public String[] getDataname(){
		return dataname;
	}
}
